module.exports = {
  "fontawesome-svg-core": {
    license: "pro",
  },
};
