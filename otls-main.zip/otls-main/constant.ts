export interface SEOProps {
  seo_title?: string | null;
  seo_description?: string | null;
}
